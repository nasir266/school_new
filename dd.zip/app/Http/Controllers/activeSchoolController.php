<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\package;
use App\Models\school;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class activeSchoolController extends Controller
{
    


}
