
                <footer class="footer-wrap-layout1">
                    <div class="copyright">© Copyrights <a href="#">Artisan</a> 2019. All rights reserved. Designed by <a
                            href="#">Developer</a></div>
                </footer>
<?php /**PATH C:\schoolm\resources\views/layout/footer.blade.php ENDPATH**/ ?>