
    </div>
</div>
    <!-- jquery-->
    <script src="<?php echo e(asset('admin/js/jquery-3.3.1.min.js')); ?>"></script>
    <!-- Plugins js -->
    <script src="<?php echo e(asset('admin/js/plugins.js')); ?>"></script>
    <!-- Popper js -->
    <script src="<?php echo e(asset('admin/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
    <!-- ========================== -->
    <!-- Counterup Js -->
    <script src="<?php echo e(asset('admin/js/jquery.counterup.min.js')); ?>"></script>
    <!-- Moment Js -->
    <script src="<?php echo e(asset('admin/js/moment.min.js')); ?>"></script>
    <!-- Waypoints Js -->
    <script src="<?php echo e(asset('admin/js/jquery.waypoints.min.js')); ?>"></script>
    <!-- Scroll Up Js -->
    <script src="<?php echo e(asset('admin/js/jquery.scrollUp.min.js')); ?>"></script>
    <!-- Select 2 Js -->
    <script src="<?php echo e(asset('admin/js/select2.min.js')); ?>"></script>
    <!-- Date Picker Js -->
    <script src="<?php echo e(asset('admin/js/datepicker.min.js')); ?>"></script>
    <!-- Full Calender Js -->
    <script src="<?php echo e(asset('admin/js/fullcalendar.min.js')); ?>"></script>
    <!-- Chart Js -->
    <script src="<?php echo e(asset('admin/js/Chart.min.js')); ?>"></script>
    <!-- Custom Js -->
    <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>

    <!-- ============================== -->

    
   
   

    
</body>


<!-- Mirrored from www.radiustheme.com/demo/html/psdboss/akkhor/akkhor/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 23 Nov 2025 07:51:40 GMT -->
</html>
<?php /**PATH C:\schoolm\resources\views/layout/bottom.blade.php ENDPATH**/ ?>