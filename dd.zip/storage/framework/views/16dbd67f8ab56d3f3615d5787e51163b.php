


<?php $__env->startSection('title', 'Dashboad'); ?>

<?php $__env->startSection('main-content'); ?>

            <!-- Sidebar Area End Here -->
            <div class="dashboard-content-one">
                <!-- Breadcubs Area Start Here -->
                <div class="breadcrumbs-area">
                    <h3>Admin Dashboard</h3>
                    <ul>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>Admin</li>
                    </ul>
                </div>
                <!-- Breadcubs Area End Here -->
                <!-- Dashboard summery Start Here -->
                <div class="row gutters-20">
                    
                </div>
                <!-- Social Media End Here -->
                <!-- Footer Area Start Here -->
                <?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <!-- Footer Area End Here -->
            </div>
        
        <!-- Page Area End Here -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\schoolm\resources\views/classes.blade.php ENDPATH**/ ?>