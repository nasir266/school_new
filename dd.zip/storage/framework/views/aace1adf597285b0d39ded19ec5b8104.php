<?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->yieldContent('main-content'); ?>                
<?php echo $__env->make('layout.bottom', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>        <?php /**PATH C:\schoolm\resources\views/layout/main.blade.php ENDPATH**/ ?>